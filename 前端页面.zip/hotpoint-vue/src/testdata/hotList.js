export default [
  {
    id: 1,
    name: "国资委：中央企业要切实增强能源电力供应的支撑托底能力",
    actor: "证券时报网",
    num: "2430000",
    type: "中性",
  },{
    id: 2,
    name: "助力上合组织国家农业现代化",
    actor: "证券网",
    num: "243",
    type: "中性",
  },{
    id: 3,
    name: "国资委：积极推进“十四五”确定的重大煤电项目落地",
    actor: "证券网",
    num: "243",
    type: "中性",
  },{
    id: 4,
    name: "助力上合组织国家农业现代化AAAAA",
    actor: "证券网",
    num: "243",
    type: "中性",
  },{
    id: 5,
    name: "助力上合组织国家农业现代化BBBBB",
    actor: "证券网",
    num: "243",
    type: "中性",
  },{
    id: 6,
    name: "助力上合组织国家农业现代化CCCCCC",
    actor: "证券网",
    num: "243",
    type: "中性",
  },{
    id: 7,
    name: "助力上合组织国家农业现代化",
    actor: "证券网",
    num: "243",
    type: "中性",
  },
]